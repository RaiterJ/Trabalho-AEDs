from model.product import Product
from model.busca import Busca
#from model.stock import Stock

if (__name__ == '__main__'):

    estoque = []
    opcao = 0
    while True:


        opcao=input('\nEscolha uma das opções abaixo:\n'
                     '[1] Pesquisar\n'
                     '[2] Adicionar\n'
                     '[3] Remover\n'
                     '[4] Alterar dados\n'
                     '[5] Visualizar estoque\n'
                     '[6] Sair\n')

        if opcao == '1': #Pesquisa de produto (Algoritmo de busca)
            opBusca = input("Escolha a opção de busca: \n"
                            "[1] Busca por Id\n"
                            "[2] Busca por nome\n")
            if opBusca == '1':
                idBusca = input("Digite o Id: ")
                Busca1 = Busca(estoque)
                print("Resultado: ", Busca1.idBusca(idBusca))

            elif opBusca == '2':
                nomeBusca = input("Digite o nome: ")
                Busca2 = Busca(estoque)
                print("Resultado: ", Busca2.nomeBusca(nomeBusca))

            else:
                print("Opção inexistente. \n")



        elif opcao =='2': #Adicionar
            print('Para adicionar um equipamento digite o id, nome, preco, tipo e quantidade respectivamente:')
            id = input()
            nome = input()
            preco = input()
            tipo = input()
            quantidade = input()

            produto = Product(id, nome, preco, tipo, quantidade) #Criar objeto produto
            estoque.append(produto.definicaoProduto()) #Lista de dicionários

            '''
            Tentando usar a classe Stock
            es = Stock(produto.definicaoProduto())
            estoque = es.gerarEstoque(produto.definicaoProduto())
            estoque = es.returnarEstoque()
            '''

        elif opcao == '3': #Excluir
            idExcluir= input('Digite o Id do produto que se deseja excluir:\n')
            for i in range(len(estoque)):
                if estoque[i]['id'] == idExcluir:
                    del estoque[i]
                    break

        elif opcao == '4': #Alterar dados
            idAlterar = input('Digite o id do produto: ')
            keyAlterar= input('Digite qual caracteristica será alterada: ')
            alteracao = input('Digite a alteração: ')
            for i in range(len(estoque)):
                if estoque[i]['id'] == idAlterar:
                   estoque[i][keyAlterar] = alteracao


        elif opcao == '5': #Visualizar estoque
            sorted_list = sorted(estoque, key=lambda k: k['id'])  # Organizar Lista de acordo com o Id
            print('Lista completa de estoque: \n')
            for i in estoque:
                print(i)



        elif opcao == '6': #Sair
            break

        else:
            print('Essa opção não existe.')

    print('Operações finalizadas')





