class Product:

    def __init__(self, id=None, nome= None, preco = None, tipo = None, quantidade = None):

        self.__id = id
        self.__nome = nome
        self.__preco = preco
        self.tipo = tipo
        self.quantidade = quantidade
        self.equipamento = {}

    @property
    def id(self):  # Reescrevendo o get, para que a variavel seja usada diretamente pelo nome
        return self.__id
    @id.setter
    def nome(self, id):  # Reescrevendo o set, para que a variavel seja usada diretamente pelo nome
        self.__id = id

    @property
    def nome(self):
        return self.__nome
    @nome.setter
    def nome(self, nome):
        self.__nome = nome

    @property
    def preco(self):
        return self.__preco
    @preco.setter
    def preco(self, preco):
        self.__preco = preco

    @property
    def tipo(self):
        return self.__tipo
    @tipo.setter
    def tipo(self, tipo):
        self.__tipo = tipo

    @property
    def quantidade(self):
        return self.__quantidade
    @quantidade.setter
    def quantidade(self, quantidade):
        self.__quantidade = quantidade

    def definicaoProduto(self):
        equipamento = {"id": self.id, "nome":self.nome, "preco":self.preco, "tipo":self.tipo, "quantidade":self.quantidade} #Dicioário
        return equipamento







