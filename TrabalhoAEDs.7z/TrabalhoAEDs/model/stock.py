
class Stock: #Deu Ruim
    def __init__(self,produto):
        self.__produto=produto
        self.__estoque =[]
        self.__estoque.append(self.__produto)

    def visualizarEstoque(self):
        for i in self.__estoque:
            print(self.__estoque)

    def returnarEstoque(self):
        return self.__estoque


    '''
    @property
    def estoque(self):
        return self.__estoque
    @estoque.setter
    def estoque(self, estoque):
        self.__estoque = estoque
    

    def gerarEstoque(self, produto):
        estoque = []
        return estoque.append(produto) #Lista de dicionários
    '''




