
class Busca:

    def __init__(self, lista):
        self.__lista = lista
        self.aux = 0

    def idBusca(self, id):
        for i in range(len(self.__lista)):
            if self.__lista[i]['id'] == id:
                return self.__lista[i]

    def nomeBusca(self, nome):
        for i in range(len(self.__lista)):
            if self.__lista[i]['nome'] == nome:
                return self.__lista[i]



